# Execution Guard — local read-only tool lab 0.1.0

Date: 2026-11-26. Isolated experiment, not a patch to Execution Guard Pro 0.6.0 and not an alternate route to any previously denied operation.

Eight bounded, deterministic computations on caller-supplied data only. No network access, GitHub writes, deploys, arbitrary execution, credential access, or persistent writes by tool handlers. This is a minimal local JSON-RPC/stdio MCP-shaped prototype, not a complete MCP implementation or a remotely hosted ChatGPT connector. No OAuth, remote transport or OpenAI approval has been tested. The code is not production-ready.

## Run

Python 3 with the versions in requirements.txt; in a local virtual environment install the dependencies from that file, then run `python -m pytest -q` and `python lab.py` for newline-delimited JSON-RPC requests. The test log is an actual local run. The server recognizes initialize, ping, tools/list and tools/call; no external SDK was installed in this environment.

## Semantics

- text_sha256: UTF-8 SHA-256, not a signature.
- evidence_bundle_verify: compare digests for supplied text, not its provenance or truth.
- acceptance_evaluate: consistency of supplied declarations and digests, not independent product acceptance.
- workflow_validate: graph validity only; no step execution.
- test_results_analyze: summarize supplied statuses; no test execution.
- snapshot_compare: compare supplied snapshots; no state writes.
- blocker_classify: classify enumerated errors; policy denials require official resolution; no retries are performed.
- release_consistency: consistency of supplied CI statuses and SHA values, not live CI validation.

All descriptors have explicit readOnlyHint=true, destructiveHint=false, openWorldHint=false, idempotentHint=true. These describe real behavior, not an exemption from host safety decisions. Schema bounds, unknown tool rejection, empty inputs and mismatches are tested. Do not send sensitive data. Local stdio assumes a trusted local caller; authentication, HTTP security, deployment, independent MCP SDK conformance and real ChatGPT discovery/calls remain untested. No changes were made to the existing repository, server or plugin.
